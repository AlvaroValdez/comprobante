import React, { useState } from "react";

export default function App() {
  const [form, setForm] = useState({
    nombre: "",
    cedula: "",
    banco: "",
    tipoCuenta: "",
    numeroCuenta: ""
  });
  const [showComprobante, setShowComprobante] = useState(false);

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowComprobante(true);
  };

  const handleEdit = () => setShowComprobante(false);

  const printComprobante = () => window.print();

  return (
    <div className="container my-5">
      <h2 className="mb-4 text-center">Generar Comprobante de Envío</h2>
      {!showComprobante ? (
        <form className="p-4 border rounded shadow mx-auto" style={{maxWidth: 500}} onSubmit={handleSubmit}>
          <div className="mb-3">
            <label className="form-label">Nombre completo beneficiario</label>
            <input
              type="text"
              className="form-control"
              name="nombre"
              value={form.nombre}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Cédula/ID/Pasaporte</label>
            <input
              type="text"
              className="form-control"
              name="cedula"
              value={form.cedula}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Banco Destino</label>
            <input
              type="text"
              className="form-control"
              name="banco"
              value={form.banco}
              onChange={handleChange}
              required
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Tipo de cuenta</label>
            <select
              className="form-select"
              name="tipoCuenta"
              value={form.tipoCuenta}
              onChange={handleChange}
              required
            >
              <option value="">Selecciona...</option>
              <option>Corriente</option>
              <option>Ahorros</option>
              <option>Digital</option>
              <option>Otro</option>
            </select>
          </div>
          <div className="mb-3">
            <label className="form-label">Número de Cuenta</label>
            <input
              type="text"
              className="form-control"
              name="numeroCuenta"
              value={form.numeroCuenta}
              onChange={handleChange}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary w-100">
            Generar Comprobante
          </button>
        </form>
      ) : (
        <div className="p-4 border rounded shadow mx-auto" style={{maxWidth: 500, background:"white"}}>
          <div className="text-center mb-4">
            <h4 className="mb-1">Comprobante de Envío</h4>
            <small>{new Date().toLocaleString()}</small>
          </div>
          <hr />
          <div>
            <p><strong>Beneficiario:</strong> {form.nombre}</p>
            <p><strong>Cédula/ID:</strong> {form.cedula}</p>
            <p><strong>Banco Destino:</strong> {form.banco}</p>
            <p><strong>Tipo de Cuenta:</strong> {form.tipoCuenta}</p>
            <p><strong>Número de Cuenta:</strong> {form.numeroCuenta}</p>
          </div>
          <hr />
          <div className="d-flex justify-content-between">
            <button className="btn btn-secondary" onClick={handleEdit}>Editar</button>
            <button className="btn btn-success" onClick={printComprobante}>
              Imprimir Comprobante
            </button>
          </div>
        </div>
      )}
      {/* Esconde todo menos el comprobante al imprimir */}
      <style>{`
        @media print {
          body * { visibility: hidden; }
          .p-4.border.rounded.shadow.mx-auto { 
            visibility: visible; 
            position: absolute; 
            left: 0; 
            top: 0; 
            width: 100vw;
            margin: 0;
            box-shadow: none !important;
          }
          .btn, .d-flex { display: none !important; }
        }
      `}</style>
    </div>
  );
}
